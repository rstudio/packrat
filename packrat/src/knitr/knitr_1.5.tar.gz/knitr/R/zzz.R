.onLoad = function(lib, pkg) {
  register_vignette_engines(pkg)
}
