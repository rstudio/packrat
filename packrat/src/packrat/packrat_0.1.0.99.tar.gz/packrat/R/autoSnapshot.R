## A snapshot function that can be called and run asynchronously
autoSnapshot <- function(projDir, packratDir) {

  ## Write a lockfile that states we're currently trying to snapshot
  file.create(file.path(packratDir, "snapshot.lock"))

  ## Build the command that can be run asynchronously
  r_path <- file.path(R.home("bin"), "R")
  autoSnapshotFilePath <- system.file(package="packrat", "autoSnapshot.R")
  cmd <- paste(
    "--vanilla",
    "--slave",
    "")

}
